import styled from "styled-components";
export const Container = styled.button`
  background-color: #1900ff;
  border-radius: 25px;
  border: 2px solid white;
`;
export const Header = styled.h1`
  color: skyblue;
  font-size: large;
`;
export const Textbox = styled.p`
  color: aliceblue;
`;
