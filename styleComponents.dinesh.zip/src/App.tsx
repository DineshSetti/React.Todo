import { Container } from "./StyledComponents";
import { Header } from "./StyledComponents";
import { Textbox } from "./StyledComponents";
import "./App.css";
function App() {
  return (
    <>
      <Container>
        <button>Submit</button>
      </Container>
      <Header>
        <h1>this is header content</h1>
      </Header>
      <Textbox>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae ducimus
          ipsam labore deleniti delectus neque, totam blanditiis ea quaerat
          exercitationem perspiciatis modi amet quisquam numquam facilis cumque
          odit. Molestias, magnam?
        </p>
      </Textbox>
    </>
  );
}

export default App;
